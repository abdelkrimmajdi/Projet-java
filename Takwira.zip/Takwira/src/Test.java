
import edu.esprit.pi.entities.Match;
import edu.esprit.pi.entities.Reponse;
import edu.esprit.pi.entities.Tournoi;
import edu.esprit.pi.services.ServiceTournoi;
import edu.esprit.pi.services.ServiceMatch;
import edu.esprit.pi.services.ServiceReclamation;
import edu.esprit.pi.services.ServiceReponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author majdiabdelkrim
 */
public class Test {
    public static void main(String[] args) {
    //Main pour Match
    //ServiceMatch service = new ServiceMatch();
    //Match mac = new Match(1,"fares","ouday");
    //service.ajouter(mac);
    ServiceTournoi service = new ServiceTournoi();
    Reponse rep =new Reponse();
   ServiceReclamation aa = new ServiceReclamation();
   aa.supprimer(9);
   
    
    
}
}
